package hust.soict.hedspi.aims.media;

public interface Playable {
    public void play();
}